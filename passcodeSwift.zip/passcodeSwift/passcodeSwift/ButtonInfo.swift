//
//  ButtonInfo.swift
//  passcodeSwift
//
//  Created by Amam Pratap Singh on 03/02/23.
//

import Foundation

enum ButtonInfo: String {
    case one = "one"
    case two = "two"
    case three = "three"
    case four = "four"
    case five = "five"
    case six = "six"
    case seven = "seven"
    case eight = "eight"
    case nine = "nine"
    case zero = "Zero"
}
