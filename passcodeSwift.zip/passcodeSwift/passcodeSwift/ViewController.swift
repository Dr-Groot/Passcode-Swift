//
//  ViewController.swift
//  passcodeSwift
//
//  Created by Amam Pratap Singh on 03/02/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var firstBlock: UIView!
    @IBOutlet var secondBlock: UIView!
    @IBOutlet var thirdBlock: UIView!
    @IBOutlet var forthBlock: UIView!
    @IBOutlet var fifthBlock: UIView!
    @IBOutlet var sixthBlock: UIView!
    @IBOutlet var one: UIButton!
    @IBOutlet var four: UIButton!
    @IBOutlet var seven: UIButton!
    @IBOutlet var two: UIButton!
    @IBOutlet var five: UIButton!
    @IBOutlet var eight: UIButton!
    @IBOutlet var zero: UIButton!
    @IBOutlet var three: UIButton!
    @IBOutlet var six: UIButton!
    @IBOutlet var nine: UIButton!

    private var borderColour: UIColor = .white
    private var borderWidth: CGFloat = 1.0
    private var textFilledCheck: [Bool] = [false, false, false, false, false, false]
    private var passcode: String = ""
    private var currentPointer = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        configPasscodeCircles(colour: borderColour, width: borderWidth)
        configNumberCircles(colour: borderColour, width: borderWidth)
    }

    private func checkAndFill(buttonInfo: ButtonInfo) {
        switch buttonInfo {
        case .one:
            passcode.append(ButtonInfo.one.rawValue)
        case .two:
            passcode.append(ButtonInfo.two.rawValue)
        case .three:
            passcode.append(ButtonInfo.three.rawValue)
        case .four:
            passcode.append(ButtonInfo.four.rawValue)
        case .five:
            passcode.append(ButtonInfo.five.rawValue)
        case .six:
            passcode.append(ButtonInfo.six.rawValue)
        case .seven:
            passcode.append(ButtonInfo.seven.rawValue)
        case .eight:
            passcode.append(ButtonInfo.eight.rawValue)
        case .nine:
            passcode.append(ButtonInfo.nine.rawValue)
        case .zero:
            passcode.append(ButtonInfo.zero.rawValue)
        }
    }

    private func checkAndFillCircle() {
        currentPointer = 0
        for val in textFilledCheck {
            currentPointer += 1
            if !val {
                textFilledCheck[currentPointer - 1] = true
                if currentPointer == 1 {
                    firstBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 2 {
                    secondBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 3 {
                    thirdBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 4 {
                    forthBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 5 {
                    fifthBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 6 {
                    sixthBlock.backgroundColor = UIColor.white
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                        self.checkPasscode(password: self.passcode)
                    })
                    break
                }
            }
        }
    }

    private func checkPasscode(password: String) {
        if password == "onetwothreefourfivesix" {
            showAlert(message: "Correct Passcode")
        } else {
            showAlert(message: "Invalid Passcode")
        }
        passcode = ""
        textFilledCheck = [false, false, false, false, false, false]
        firstBlock.backgroundColor = UIColor.black
        secondBlock.backgroundColor = UIColor.black
        thirdBlock.backgroundColor = UIColor.black
        forthBlock.backgroundColor = UIColor.black
        fifthBlock.backgroundColor = UIColor.black
        sixthBlock.backgroundColor = UIColor.black
    }

    private func showAlert(message: String) {
        let alert = UIAlertController(title: message, message: "", preferredStyle: .alert)
        self.present(alert, animated: true, completion: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
            alert.dismiss(animated: true, completion: nil)
        })
    }

    @IBAction func didTapTwoButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .two)
        checkAndFillCircle()
    }

    @IBAction func didTapFiveButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .five)
        checkAndFillCircle()
    }

    @IBAction func didTapEightButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .eight)
        checkAndFillCircle()
    }

    @IBAction func didTapZeroButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .zero)
        checkAndFillCircle()
    }

    @IBAction func didTapOneButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .one)
        checkAndFillCircle()
    }

    @IBAction func didTapFourButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .four)
        checkAndFillCircle()
    }

    @IBAction func didTapSevenButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .seven)
        checkAndFillCircle()
    }

    @IBAction func didTapThreeButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .three)
        checkAndFillCircle()
    }

    @IBAction func didTapSixButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .six)
        checkAndFillCircle()
    }

    @IBAction func didTapNineButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .nine)
        checkAndFillCircle()
    }
}

extension ViewController {
    private func configPasscodeCircles(colour: UIColor, width: CGFloat) {
        firstBlock.backgroundColor = UIColor.black
        secondBlock.backgroundColor = UIColor.black
        thirdBlock.backgroundColor = UIColor.black
        forthBlock.backgroundColor = UIColor.black
        fifthBlock.backgroundColor = UIColor.black
        sixthBlock.backgroundColor = UIColor.black

        firstBlock.layer.cornerRadius = (firstBlock.frame.size.width < firstBlock.frame.size.height) ? firstBlock.frame.size.width / 2.0 : firstBlock.frame.size.height / 2.0
        firstBlock.layer.borderColor = colour.cgColor
        firstBlock.layer.borderWidth = width

        secondBlock.layer.cornerRadius = (secondBlock.frame.size.width < secondBlock.frame.size.height) ? secondBlock.frame.size.width / 2.0 : secondBlock.frame.size.height / 2.0
        secondBlock.layer.borderColor = colour.cgColor
        secondBlock.layer.borderWidth = width

        thirdBlock.layer.cornerRadius = (thirdBlock.frame.size.width < thirdBlock.frame.size.height) ? thirdBlock.frame.size.width / 2.0 : thirdBlock.frame.size.height / 2.0
        thirdBlock.layer.borderColor = colour.cgColor
        thirdBlock.layer.borderWidth = width

        forthBlock.layer.cornerRadius = (forthBlock.frame.size.width < forthBlock.frame.size.height) ? forthBlock.frame.size.width / 2.0 : forthBlock.frame.size.height / 2.0
        forthBlock.layer.borderColor = colour.cgColor
        forthBlock.layer.borderWidth = width

        fifthBlock.layer.cornerRadius = (fifthBlock.frame.size.width < fifthBlock.frame.size.height) ? fifthBlock.frame.size.width / 2.0 : fifthBlock.frame.size.height / 2.0
        fifthBlock.layer.borderColor = colour.cgColor
        fifthBlock.layer.borderWidth = width

        sixthBlock.layer.cornerRadius = (sixthBlock.frame.size.width < sixthBlock.frame.size.height) ? sixthBlock.frame.size.width / 2.0 : sixthBlock.frame.size.height / 2.0
        sixthBlock.layer.borderColor = colour.cgColor
        sixthBlock.layer.borderWidth = width
    }

    private func configNumberCircles(colour: UIColor, width: CGFloat) {
        one.layer.cornerRadius = (one.frame.size.width < one.frame.size.height) ? one.frame.size.width / 2.0 : one.frame.size.height / 2.0
        one.tintColor = colour
        one.layer.borderColor = colour.cgColor
        one.layer.borderWidth = width

        two.layer.cornerRadius = (two.frame.size.width < two.frame.size.height) ? two.frame.size.width / 2.0 : two.frame.size.height / 2.0
        two.layer.borderColor = colour.cgColor
        two.layer.borderWidth = width
        two.tintColor = colour
        
        three.layer.cornerRadius = (three.frame.size.width < three.frame.size.height) ?  three.frame.size.width / 2.0 : three.frame.size.height / 2.0
        three.layer.borderColor = colour.cgColor
        three.layer.borderWidth = width
        three.tintColor = colour
        
        four.layer.cornerRadius = (four.frame.size.width < four.frame.size.height) ? four.frame.size.width / 2.0 : four.frame.size.height / 2.0
        four.layer.borderColor = colour.cgColor
        four.layer.borderWidth = width
        four.tintColor = colour
        
        five.layer.cornerRadius = (five.frame.size.width < five.frame.size.height) ? five.frame.size.width / 2.0 : five.frame.size.height / 2.0
        five.layer.borderColor = colour.cgColor
        five.layer.borderWidth = width
        five.tintColor = colour
        
        six.layer.cornerRadius = (six.frame.size.width < six.frame.size.height) ? six.frame.size.width / 2.0 : six.frame.size.height / 2.0
        six.layer.borderColor = colour.cgColor
        six.layer.borderWidth = width
        six.tintColor = colour
        
        seven.layer.cornerRadius = (seven.frame.size.width < seven.frame.size.height) ? seven.frame.size.width / 2.0 : seven.frame.size.height / 2.0
        seven.layer.borderColor = colour.cgColor
        seven.layer.borderWidth = width
        seven.tintColor = colour
        
        eight.layer.cornerRadius = (eight.frame.size.width < eight.frame.size.height) ? eight.frame.size.width / 2.0 : eight.frame.size.height / 2.0
        eight.layer.borderColor = colour.cgColor
        eight.layer.borderWidth = width
        eight.tintColor = colour
        
        nine.layer.cornerRadius = (nine.frame.size.width < nine.frame.size.height) ? nine.frame.size.width / 2.0 : nine.frame.size.height / 2.0
        nine.layer.borderColor = colour.cgColor
        nine.layer.borderWidth = width
        nine.tintColor = colour
        
        zero.layer.cornerRadius = (zero.frame.size.width < zero.frame.size.height) ? zero.frame.size.width / 2.0 : zero.frame.size.height / 2.0
        zero.layer.borderColor = colour.cgColor
        zero.layer.borderWidth = width
        zero.tintColor = colour
    }
}
